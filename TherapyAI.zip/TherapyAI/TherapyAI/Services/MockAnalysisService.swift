import Foundation

enum MockAnalysisService {
    static func analyze(videoURL: URL) async -> AnalysisResult {
        // Return the hardcoded example for now
        return AnalysisResult(
            transcript: [
                TranscriptSegment(id: UUID(), text: "I have had a really good day today.", startTime: 0.0, endTime: 2.8, sentiment: .positive, isQuestion: false),
                TranscriptSegment(id: UUID(), text: "I was wondering what activities I can do to close out my day?", startTime: 3.0, endTime: 6.5, sentiment: .neutral, isQuestion: true)
            ],
            snapshots: [
                EmotionSnapshot(id: UUID(), time: 0.0, emotion: "happy", confidence: 0.93),
                EmotionSnapshot(id: UUID(), time: 3.0, emotion: "neutral", confidence: 0.88)
            ],
            summary: AnalysisSummary(
                overallSentiment: .positive,
                counts: [.positive: 2, .neutral: 1],
                notes: "Overall, 2 positive, 1 neutral, 1 question: positive"
            ),
            modelResponse: "I am glad you had a good day! You can close out your joyous day by: meditating, etc."
        )
    }
}
