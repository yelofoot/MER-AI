import AVFoundation
import SwiftUI
import Combine
import Photos

@MainActor
final class CameraService: NSObject, ObservableObject {
    enum CameraPosition {
        case front
        case back
    }

    @Published var isSessionRunning: Bool = false
    @Published var isAuthorized: Bool = false
    @Published var isUsingFrontCamera: Bool = false
    @Published var isTorchOn: Bool = false
    @Published var lastPhoto: UIImage? = nil
    @Published var errorMessage: String? = nil

    let session = AVCaptureSession()

    private let sessionQueue = DispatchQueue(label: "camera.session.queue")
    private var videoDeviceInput: AVCaptureDeviceInput?
    private var audioDeviceInput: AVCaptureDeviceInput?
    private let photoOutput = AVCapturePhotoOutput()
    private let movieOutput = AVCaptureMovieFileOutput()

    @Published var isRecording: Bool = false

    override init() {
        super.init()
        // Configure session preset for photo quality similar to Snapchat
        session.sessionPreset = .photo
    }

    func requestAuthorization() async {
        // Request camera permission
        let cameraStatus = AVCaptureDevice.authorizationStatus(for: .video)
        let cameraGranted: Bool
        switch cameraStatus {
        case .authorized:
            cameraGranted = true
        case .notDetermined:
            cameraGranted = await withCheckedContinuation { (continuation: CheckedContinuation<Bool, Never>) in
                AVCaptureDevice.requestAccess(for: .video) { granted in
                    continuation.resume(returning: granted)
                }
            }
        default:
            cameraGranted = false
        }

        // Request microphone permission (for video with audio). Recording can proceed without it, but audio will be absent.
        let micStatus = AVCaptureDevice.authorizationStatus(for: .audio)
        let micGranted: Bool
        switch micStatus {
        case .authorized:
            micGranted = true
        case .notDetermined:
            micGranted = await withCheckedContinuation { (continuation: CheckedContinuation<Bool, Never>) in
                AVCaptureDevice.requestAccess(for: .audio) { granted in
                    continuation.resume(returning: granted)
                }
            }
        default:
            micGranted = false
        }

        self.isAuthorized = cameraGranted
        if !cameraGranted {
            self.errorMessage = "Camera access is required. Please enable it in Settings."
            return
        }

        await configureSessionIfNeeded(addAudio: micGranted)
    }

    func configureSessionIfNeeded(addAudio: Bool = false) async {
        await withCheckedContinuation { continuation in
            sessionQueue.async {
                guard self.videoDeviceInput == nil else {
                    continuation.resume()
                    return
                }
                self.session.beginConfiguration()
                defer { self.session.commitConfiguration() }

                // Add video input (default to back camera)
                do {
                    guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                        DispatchQueue.main.async { self.errorMessage = "No back camera available." }
                        continuation.resume()
                        return
                    }
                    let input = try AVCaptureDeviceInput(device: device)
                    if self.session.canAddInput(input) {
                        self.session.addInput(input)
                        self.videoDeviceInput = input
                        DispatchQueue.main.async { self.isUsingFrontCamera = (device.position == .front) }
                    }
                } catch {
                    DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
                }

                // Add audio input if permitted
                if addAudio {
                    do {
                        if let audioDevice = AVCaptureDevice.default(for: .audio) {
                            let audioInput = try AVCaptureDeviceInput(device: audioDevice)
                            if self.session.canAddInput(audioInput) {
                                self.session.addInput(audioInput)
                                self.audioDeviceInput = audioInput
                            }
                        }
                    } catch {
                        DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
                    }
                }

                // Add photo output
                if self.session.canAddOutput(self.photoOutput) {
                    self.session.addOutput(self.photoOutput)
                    self.photoOutput.isHighResolutionCaptureEnabled = true
                }

                // Add movie output for video recording
                if self.session.canAddOutput(self.movieOutput) {
                    self.session.addOutput(self.movieOutput)
                }

                continuation.resume()
            }
        }
    }

    func startSession() {
        sessionQueue.async {
            guard !self.session.isRunning else { return }
            self.session.startRunning()
            DispatchQueue.main.async { self.isSessionRunning = true }
        }
    }

    func stopSession() {
        sessionQueue.async {
            guard self.session.isRunning else { return }
            self.session.stopRunning()
            DispatchQueue.main.async { self.isSessionRunning = false }
        }
    }

    func switchCamera() {
        sessionQueue.async {
            guard let currentInput = self.videoDeviceInput else { return }
            let currentPosition = currentInput.device.position
            let preferredPosition: AVCaptureDevice.Position = (currentPosition == .back) ? .front : .back

            guard let newDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: preferredPosition) else { return }

            do {
                let newInput = try AVCaptureDeviceInput(device: newDevice)
                self.session.beginConfiguration()
                self.session.removeInput(currentInput)
                if self.session.canAddInput(newInput) {
                    self.session.addInput(newInput)
                    self.videoDeviceInput = newInput
                } else {
                    // Revert if failed
                    if self.session.canAddInput(currentInput) {
                        self.session.addInput(currentInput)
                    }
                }
                self.session.commitConfiguration()
                DispatchQueue.main.async { self.isUsingFrontCamera = (preferredPosition == .front) }
            } catch {
                DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
            }
        }
    }

    func toggleTorch() {
        sessionQueue.async {
            guard let device = self.videoDeviceInput?.device, device.hasTorch else { return }
            do {
                try device.lockForConfiguration()
                let newValue = !device.isTorchActive
                if newValue {
                    try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                } else {
                    device.torchMode = .off
                }
                device.unlockForConfiguration()
                DispatchQueue.main.async { self.isTorchOn = newValue }
            } catch {
                DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
            }
        }
    }

    func startRecording() {
        sessionQueue.async {
            guard !self.movieOutput.isRecording else { return }
            // Stabilization / max duration settings can be configured here if desired
            if let connection = self.movieOutput.connection(with: .video), connection.isVideoStabilizationSupported {
                connection.preferredVideoStabilizationMode = .standard
            }

            let outputURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension("mov")
            self.movieOutput.startRecording(to: outputURL, recordingDelegate: self)
            DispatchQueue.main.async { self.isRecording = true }
        }
    }

    func stopRecording() {
        sessionQueue.async {
            guard self.movieOutput.isRecording else { return }
            self.movieOutput.stopRecording()
        }
    }

    private func saveRecordedVideo(at url: URL) {
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else { return }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }) { success, error in
                // Cleanup temp file
                try? FileManager.default.removeItem(at: url)
                if let error = error {
                    DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
                }
            }
        }
    }

    func capturePhoto() {
        let settings = AVCapturePhotoSettings()
        settings.isHighResolutionPhotoEnabled = true
        if let device = videoDeviceInput?.device, device.hasFlash, !isUsingFrontCamera {
            // Use flash setting only for back camera
            settings.flashMode = isTorchOn ? .on : .off
        }
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
}

extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
            return
        }
        guard let data = photo.fileDataRepresentation(), let image = UIImage(data: data) else { return }
        DispatchQueue.main.async { self.lastPhoto = image }
    }
}

extension CameraService: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async { self.isRecording = false }
        if let error = error {
            DispatchQueue.main.async { self.errorMessage = error.localizedDescription }
            // Remove temp file on failure
            try? FileManager.default.removeItem(at: outputFileURL)
            return
        }
        // Save to Photos
        self.saveRecordedVideo(at: outputFileURL)
    }
}
