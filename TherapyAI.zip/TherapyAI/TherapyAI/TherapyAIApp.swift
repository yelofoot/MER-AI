//
//  TherapyAIApp.swift
//  TherapyAI
//
//  Created by Tyler Austin on 9/23/25.
//

import SwiftUI

@main
struct TherapyAIApp: App {
    @AppStorage("hasSeenWelcome") private var hasSeenWelcome = false

    var body: some Scene {
        WindowGroup {
            if hasSeenWelcome {
                CameraView()
            } else {
                WelcomeView(onContinue: { hasSeenWelcome = true })
            }
        }
    }
}
