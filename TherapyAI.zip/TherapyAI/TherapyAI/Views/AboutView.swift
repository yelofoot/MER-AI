import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("About This Prototype")
                .font(.title)
                .bold()
            
            Text("This prototype demonstrates the core features and user interface of our application. It is designed to provide a clear and interactive experience.")
                .font(.body)
            
            Text("Help")
                .font(.headline)
                .padding(.top, 20)
            
            Text("Use the tabs below to navigate through the app. Tap on items to view details and use the settings to customize your experience.")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
