import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct HomeView: View {
    @State private var showPicker = false
    @State private var isAnalyzing = false
    @State private var errorMessage: String? = nil
    let onAnalysisComplete: (AnalysisResult) -> Void

    var body: some View {
        ZStack {
            VStack(spacing: 16) {
                Button {
                    showPicker = true
                } label: {
                    Label("Upload MP4", systemImage: "square.and.arrow.up")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(isAnalyzing)

                NavigationLink {
                    LiveRecordView(onAnalysisComplete: onAnalysisComplete)
                } label: {
                    Label("Live Feed (Record)", systemImage: "video.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .disabled(isAnalyzing)

                Spacer()
            }
            .padding()

            if isAnalyzing {
                Color.black.opacity(0.2).ignoresSafeArea()
                ProgressView("Analyzing…")
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
        .sheet(isPresented: $showPicker) {
            VideoPicker { url in
                guard let url = url else {
                    errorMessage = "No video selected."
                    return
                }
                isAnalyzing = true
                Task {
                    defer { isAnalyzing = false }
                    let result = await MockAnalysisService.analyze(videoURL: url)
                    onAnalysisComplete(result)
                }
            }
        }
        .alert("Error", isPresented: .constant(errorMessage != nil), actions: {
            Button("OK") { errorMessage = nil }
        }, message: {
            Text(errorMessage ?? "")
        })
    }
}

// MARK: - Video Picker
struct VideoPicker: UIViewControllerRepresentable {
    var onPicked: (URL?) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPicked: onPicked) }

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration(photoLibrary: .shared())
        config.filter = .videos
        config.selectionLimit = 1
        let vc = PHPickerViewController(configuration: config)
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onPicked: (URL?) -> Void
        init(onPicked: @escaping (URL?) -> Void) { self.onPicked = onPicked }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let item = results.first else { onPicked(nil); return }
            let provider = item.itemProvider
            guard provider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) else {
                onPicked(nil); return
            }
            provider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { url, error in
                guard let url = url, error == nil else { DispatchQueue.main.async { self.onPicked(nil) }; return }
                let tempURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent(UUID().uuidString)
                    .appendingPathExtension("mp4")
                do {
                    if FileManager.default.fileExists(atPath: tempURL.path) {
                        try FileManager.default.removeItem(at: tempURL)
                    }
                    try FileManager.default.copyItem(at: url, to: tempURL)
                    DispatchQueue.main.async { self.onPicked(tempURL) }
                } catch {
                    DispatchQueue.main.async { self.onPicked(nil) }
                }
            }
        }
    }
}

#Preview {
    NavigationStack {
        HomeView { _ in }
            .navigationTitle("Home")
    }
}
