import SwiftUI

struct AppShellView: View {
    @State private var latestResult: AnalysisResult?

    var body: some View {
        TabView {
            NavigationStack {
                HomeView { result in
                    latestResult = result
                }
                .navigationTitle("Home")
            }
            .tabItem { Label("Home", systemImage: "house") }

            NavigationStack {
                OutputView(result: latestResult)
                    .navigationTitle("Output")
            }
            .tabItem { Label("Output", systemImage: "chart.bar.doc.horizontal") }

            NavigationStack {
                AboutView()
                    .navigationTitle("About")
            }
            .tabItem { Label("About", systemImage: "questionmark.circle") }
        }
    }
}

#Preview {
    AppShellView()
}
