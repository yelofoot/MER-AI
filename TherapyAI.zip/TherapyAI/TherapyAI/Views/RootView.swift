import SwiftUI

struct RootView: View {
    @State private var hasSeenWelcome = false

    var body: some View {
        if hasSeenWelcome {
            AppShellView()
        } else {
            WelcomeView(onContinue: {
                hasSeenWelcome = true
            })
        }
    }
}

#Preview {
    RootView()
}
