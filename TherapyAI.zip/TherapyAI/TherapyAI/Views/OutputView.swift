import SwiftUI

struct OutputView: View {
    let result: AnalysisResult?

    var body: some View {
        ScrollView {
            if let result {
                VStack(alignment: .leading, spacing: 16) {
                    // Model Response Section
                    Text("Model Response")
                        .font(.headline)
                    Text(result.modelResponse)
                        .padding(.bottom, 8)

                    Divider()

                    // Summary Section
                    Text("Summary")
                        .font(.headline)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Overall Sentiment: \(result.summary.overallSentiment.rawValue.capitalized)")
                        if !result.summary.notes.isEmpty {
                            Text(result.summary.notes)
                        }
                    }

                    Divider()

                    // Transcript Analysis Section
                    Text("Transcript Analysis")
                        .font(.headline)
                    ForEach(result.transcript) { segment in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(segment.text)
                            HStack(spacing: 8) {
                                Text("Sentiment: \(segment.sentiment.rawValue.capitalized)")
                                if segment.isQuestion { Text("Question").italic() }
                            }
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                        Divider()
                    }

                    // Emotion Snapshots Section
                    Text("Emotion Snapshots")
                        .font(.headline)
                    ForEach(result.snapshots) { snapshot in
                        HStack {
                            Text(String(format: "t=%.1fs", snapshot.time))
                            Spacer()
                            Text(snapshot.emotion.capitalized)
                            Spacer()
                            Text(String(format: "%.0f%%", snapshot.confidence * 100))
                        }
                        .padding(.vertical, 4)
                        Divider()
                    }
                }
                .padding()
            } else {
                VStack(spacing: 12) {
                    Text("No Analysis Available")
                        .font(.title2).bold()
                    Text("Upload a video or record a clip on the Home tab to see results here.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal)
                }
                .padding()
            }
        }
    }
}

#Preview {
    OutputView(result: nil)
}
