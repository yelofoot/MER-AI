import SwiftUI

struct WelcomeView: View {
    var onContinue: () -> Void

    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(colors: [Color.indigo, Color.blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                Image(systemName: "camera.aperture")
                    .symbolRenderingMode(.hierarchical)
                    .font(.system(size: 72, weight: .bold))
                    .foregroundStyle(.white)

                VStack(spacing: 8) {
                    Text("Welcome to TherapyAI")
                        .font(.largeTitle.bold())
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white)

                    Text("Capture moments and insights with a simple, privacy‑first camera experience.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white.opacity(0.9))
                        .padding(.horizontal)
                }

                Spacer()

                Button(action: onContinue) {
                    Text("Get Started")
                        .font(.headline)
                        .padding(.horizontal, 28)
                        .padding(.vertical, 14)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.white)
                .foregroundStyle(.blue)
                .controlSize(.large)
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(.ultraThinMaterial)
                        .opacity(0.2)
                )
                .padding(.horizontal)

                // Optional: small note about permissions
                Text("We’ll ask for camera access on the next screen.")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.8))
                    .padding(.top, 4)

                Spacer().frame(height: 24)
            }
            .padding()
        }
    }
}

#Preview {
    WelcomeView(onContinue: {})
}
