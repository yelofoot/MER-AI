import SwiftUI

struct LiveRecordView: View {
    let onAnalysisComplete: (AnalysisResult) -> Void
    @State private var isAnalyzing = false

    var body: some View {
        ZStack {
            VStack(spacing: 16) {
                Text("Live recording prototype coming soon.")
                    .foregroundStyle(.secondary)
                Button("Simulate Recording → Analyze") {
                    isAnalyzing = true
                    Task {
                        defer { isAnalyzing = false }
                        let fakeURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("fake.mp4")
                        let result = await MockAnalysisService.analyze(videoURL: fakeURL)
                        onAnalysisComplete(result)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isAnalyzing)
                Spacer()
            }
            .padding()

            if isAnalyzing {
                Color.black.opacity(0.2).ignoresSafeArea()
                ProgressView("Analyzing…")
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
        .navigationTitle("Live Record")
    }
}

#Preview {
    NavigationStack { LiveRecordView { _ in } }
}
