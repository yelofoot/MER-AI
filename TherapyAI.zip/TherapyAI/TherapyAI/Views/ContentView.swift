//
//  ContentView.swift
//  TherapyAI
//
//  Created by Tyler Austin on 9/23/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            // Main camera tab
            CameraView()
                .tabItem {
                    Image(systemName: "camera.fill")
                    Text("Camera")
                }

            // Placeholder for "Chats" or other feature
            NavigationStack {
                VStack(spacing: 16) {
                    Text("Coming Soon")
                        .font(.title3.weight(.semibold))
                    Text("Build out your therapy features here.")
                        .foregroundStyle(.secondary)
                }
                .navigationTitle("Explore")
            }
            .tabItem {
                Image(systemName: "bubble.left.and.bubble.right")
                Text("Explore")
            }
        }
    }
}

#Preview {
    ContentView()
}
