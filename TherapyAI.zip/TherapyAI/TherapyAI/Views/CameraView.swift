import SwiftUI

struct CameraView: View {
    @StateObject private var camera = CameraService()
    @State private var showPermissionAlert = false
    @State private var showPhotoPreview = false
    @AppStorage("hasSeenWelcome") private var hasSeenWelcome = false
    @State private var showResetConfirm = false

    var body: some View {
        ZStack {
            // Live camera preview
            CameraPreviewView(session: camera.session)
                .ignoresSafeArea()
                .overlay(alignment: .top) { topBar }
                .overlay(alignment: .bottom) { bottomBar }
                .overlay(alignment: .trailing) { sideBar }

            if let img = camera.lastPhoto, showPhotoPreview {
                Color.black.opacity(0.9).ignoresSafeArea()
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .padding()
                    .onTapGesture { withAnimation { showPhotoPreview = false } }
            }
        }
        .task {
            await camera.requestAuthorization()
            if camera.isAuthorized { camera.startSession() } else { showPermissionAlert = true }
        }
        .onDisappear { camera.stopSession() }
        .alert("Camera Permission Needed", isPresented: $showPermissionAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(camera.errorMessage ?? "Please enable camera access in Settings > Privacy > Camera.")
        }
#if DEBUG
        .confirmationDialog("Reset Onboarding?", isPresented: $showResetConfirm, titleVisibility: .visible) {
            Button("Reset", role: .destructive) {
                hasSeenWelcome = false
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will show the welcome screen again on next launch.")
        }
#endif
    }

    private var topBar: some View {
        HStack {
            // Left: settings placeholder
            Button {
                // open settings or app menu
            } label: {
                Image(systemName: "gearshape")
                    .font(.system(size: 18, weight: .semibold))
                    .padding(10)
                    .background(.ultraThinMaterial, in: Circle())
            }
#if DEBUG
            .contextMenu {
                Button(role: .destructive) {
                    showResetConfirm = true
                } label: {
                    Label("Reset Onboarding", systemImage: "arrow.counterclockwise")
                }
            }
#endif

            Spacer()

            // Center: app title/logo placeholder
            Text("TherapyAI")
                .font(.headline)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial, in: Capsule())

            Spacer()

            // Right: flash/torch toggle
            Button {
                camera.toggleTorch()
            } label: {
                Image(systemName: camera.isTorchOn ? "bolt.fill" : "bolt.slash")
                    .font(.system(size: 18, weight: .semibold))
                    .padding(10)
                    .background(.ultraThinMaterial, in: Circle())
            }
        }
        .padding(.horizontal)
        .padding(.top, 12)
    }

    private var bottomBar: some View {
        VStack(spacing: 12) {
            // Mode selector placeholder (e.g., Photo / Video / etc.)
            Text("PHOTO")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.9))
                .padding(.vertical, 2)
                .padding(.horizontal, 8)
                .background(.ultraThinMaterial, in: Capsule())

            HStack {
                // Left: last photo thumbnail
                Button {
                    if camera.lastPhoto != nil { withAnimation { showPhotoPreview = true } }
                } label: {
                    Group {
                        if let img = camera.lastPhoto {
                            Image(uiImage: img).resizable().scaledToFill()
                        } else {
                            Image(systemName: "photo")
                                .symbolRenderingMode(.hierarchical)
                                .foregroundStyle(.white)
                                .padding(8)
                        }
                    }
                    .frame(width: 48, height: 48)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                }

                Spacer()

                // Center: shutter button
                Button {
                    camera.capturePhoto()
                } label: {
                    ZStack {
                        Circle().fill(.white.opacity(0.2)).frame(width: 84, height: 84)
                        Circle().fill(.white).frame(width: 68, height: 68)
                    }
                }
                .buttonStyle(.plain)

                Spacer()

                // Right: flip camera
                Button { camera.switchCamera() } label: {
                    Image(systemName: "arrow.triangle.2.circlepath.camera")
                        .font(.system(size: 22, weight: .semibold))
                        .padding(12)
                        .background(.ultraThinMaterial, in: Circle())
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 24)
        }
        .foregroundStyle(.white)
        .shadow(radius: 10)
    }

    private var sideBar: some View {
        VStack(spacing: 16) {
            Spacer()
            // Placeholder for vertical controls (e.g., timer, filters, etc.)
            Button { /* filters */ } label: {
                Image(systemName: "wand.and.stars")
                    .font(.system(size: 18, weight: .semibold))
                    .padding(10)
                    .background(.ultraThinMaterial, in: Circle())
            }
        }
        .padding(.trailing, 12)
        .padding(.bottom, 160) // keep clear of bottom bar
    }
}

#Preview {
    CameraView()
}
