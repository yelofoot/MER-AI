import Foundation

// Canonical sentiment enum used throughout the app
public enum Sentiment: String, Codable {
    case positive
    case neutral
    case negative
    case mixed
}

// A single transcript segment with timing, sentiment, and question flag
public struct TranscriptSegment: Identifiable, Codable {
    public let id: UUID
    public let text: String
    public let startTime: TimeInterval
    public let endTime: TimeInterval
    public let sentiment: Sentiment
    public let isQuestion: Bool
}

// A snapshot of facial emotion at a particular time with confidence
public struct EmotionSnapshot: Identifiable, Codable {
    public let id: UUID
    public let time: TimeInterval
    public let emotion: String
    public let confidence: Double
}

// Summary of the overall analysis
public struct AnalysisSummary: Codable {
    public let overallSentiment: Sentiment
    public let counts: [Sentiment: Int]
    public let notes: String
}

// Top-level result returned by the analysis pipeline
public struct AnalysisResult: Codable {
    public let transcript: [TranscriptSegment]
    public let snapshots: [EmotionSnapshot]
    public let summary: AnalysisSummary
    public let modelResponse: String
}
